package com.ShopSphere.shop_sphere.repository;

import com.ShopSphere.shop_sphere.model.Wishlist;

public interface WishlistDao {
	
	int createWishlist(int userId);
	Wishlist findByUserId(int userId);

}
