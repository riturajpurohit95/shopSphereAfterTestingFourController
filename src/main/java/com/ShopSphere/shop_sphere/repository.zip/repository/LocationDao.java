package com.ShopSphere.shop_sphere.repository;

import java.util.List;

import com.ShopSphere.shop_sphere.model.Location;

public interface LocationDao {
	
	int save(Location location);
	Location finndById(int location);
	List<Location> finAll();

}
