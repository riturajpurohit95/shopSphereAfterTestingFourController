package com.ShopSphere.shop_sphere.repository;

import java.util.List;

import com.ShopSphere.shop_sphere.model.CartItem;

public interface CartItemDao {
	
	int addItem(CartItem cartItem);
	List<CartItem> findByCartId(int cartId);
	int updateItemQuantity(int cartItemId, int quantity);
	int deleteItem(int cartItemId);

}
