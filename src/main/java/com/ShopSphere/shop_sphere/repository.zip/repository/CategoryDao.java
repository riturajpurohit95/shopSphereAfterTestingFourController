package com.ShopSphere.shop_sphere.repository;

import java.util.List;

import com.ShopSphere.shop_sphere.model.Category;

public interface CategoryDao {
	
	int save(Category category);
	Category findById(int categoryId);
	List<Category> findAll();
	int update(Category category);
	int delete(int categoryId);

}
